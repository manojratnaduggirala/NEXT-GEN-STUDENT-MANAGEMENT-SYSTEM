from .dashboard_views import *
from .user_views import *
from .course_views import *
from .attendance_views import *
from .marks_views import *
from .task_views import *
from .event_views import *
from .certification_views import *
from .performance_views import *
from .common import *
from .dashboard_views import mark_notification_read 
from .user_views import custom_logout
from .exam_views import ExamManagementView
from .common import settings_view, notifications_view, send_notification
