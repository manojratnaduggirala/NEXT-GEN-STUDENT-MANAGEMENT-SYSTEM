default_app_config = 'next_gen_sms.apps.NextGenSmsConfig'
import pymysql
pymysql.install_as_MySQLdb()
